// ============================================================
// DEVELOPER PANEL v9.2 (WELP v15.2), route ?dev=panel.
// v15.1 PERUBAHAN:
//   • Allowlist email developer (DEV_EMAILS), hapus tenant hanya
//     utk email di daftar + email terverifikasi (selaras rules v15.1).
// v9.2 HARDENING (WELP v15.2):
//   • Generator kredensial pakai crypto.getRandomValues (bukan
//     Math.random yang bisa diprediksi), password 10 char.
//   • Kebijakan kredensial registrasi: PIN wajib 6 digit, password
//     min. 8 char, ID tenant min. 3 char tanpa spasi.
//   • Rules v15.2: licenses list/create/update dikunci ke dev
//     (upgrade plaintext→hash lama tetap diizinkan utk tenant legacy).
//   • Hapus tenant: konfirmasi 2 langkah + bersih-bersih data
//     tenants/{lic} (best-effort) setelah lisensi terhapus.
//   • Registrasi tenant: modal KREDENSI TAMPAK SEKALI (copy)  
//     catat sebelum menutup; setelah itu tersimpan hash.
//   • Banner + tombol kirim verifikasi email bila belum verified.
// v9.1 FIX (link verifikasi "sudah digunakan"):
//   • Tombol CEK STATUS: reload user + paksa refresh token → badge langsung
//     jujur (sebelumnya: email sudah terverifikasi tapi badge tetap kuning
//     karena status sesi tidak pernah di-refresh).
//   • Setelah verifikasi sukses, halaman Firebase me-redirect balik ke
//     panel → status otomatis di-refresh, tidak perlu logout-login.
//   • Cooldown kirim 45 dtk: kirim ulang MEMATIKAN link sebelumnya
//     (Firebase hanya mengizinkan 1 link terbaru per user).
//   • actionCodeSettings.url → balik ke panel, bukan halaman kosong.
// v21.2.0, MODE TANPA CLOUD FUNCTIONS (plan Spark/plan gratis):
//   • FAkTA: plan Spark TIDAK bisa deploy Cloud Functions (butuh Blaze)
//     → dulu "Gagal simpan: internal" PASTI terjadi (endpoint tidak ada).
//   • Simpan tenant kini 100% klien & tetap aman: akun Auth dibuat via
//     app sekunder, privilege disimpan di welp_identities/{uid} yang HANYA
//     bisa ditulis developer allowlist (rules), setara claims.
//   • Email verifikasi owner dikirim otomatis (tanpa server) + tombol
//     kirim ulang di modal kredensial.
//   • Login Akun WELP: sesi dibangun dari welp_identities + licenses.
//   • Semua error server/pesan dijelaskan (tidak ada "internal" telanjang).
// v21.1.3 PERBAIKAN (bug "Gagal simpan: internal"):
//   • Error server kini dijelaskan (explainFnError), tidak ada lagi
//     kata "internal" telanjang tanpa petunjuk tindakan.
//   • Simpan tenant idempoten & tahan gagal separuh jalan: identity
//     dulu → lisensi → link verifikasi BEST-EFFORT + tombol coba lagi
//     di modal kredensial (gagal kirim link tidak membatalkan tenant).
//   • Password Acak kini kelas lengkap (besar/kecil/angka/simbol)  
//     lolos password policy ketat sekalipun, entropi lebih tinggi.
// ============================================================
import React, { useState, useEffect, useReducer, useRef } from 'react';
import { db, auth, firebaseInitError, fileToDataUrl, hexToTriplet, writeBrandMirror, makeCred, anonAuthBlocked, provisionWelpIdentityClient, welpResendVerification } from './core.jsx';
import {
  getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut, sendEmailVerification, applyActionCode
} from 'firebase/auth';
import {
  collection, doc, setDoc, getDoc, getDocs, updateDoc, deleteDoc, writeBatch, onSnapshot, query, orderBy
} from 'firebase/firestore';
import { AppSymbol, Mascot } from './brand.jsx';
import {
  PerisaiBuddy, GembokBuddy, Lisensi, Trash2, Copy, Check,
  MonitorPusat, Kredensial, WaktuReal, BahayaBuddy, KoinBuddy, Terang, Gelap, Toko
} from './welp-icons.jsx';

// v15.1: allowlist developer, email di sini + email_verified di Firebase
// = boleh menghapus tenant (selaras function isDev() di firestore.rules).
const DEV_EMAILS = ['shandikazaid@gmail.com'];

// v21.1.2: baca env SECARA LANGSUNG, independen dari hasil init Firebase.
// Kegunaan: membedakan "config nggak ikut ter-build" (apiKey kosong) dari
// "kredensial salah". import.meta.env dibaca saat dev-server start / build,
// jadi kalau .env dibuat SETELAH build, nilainya tetap kosong di build lama.
const ENV_KEY_OK = !!String(import.meta.env.VITE_FIREBASE_API_KEY || '').trim();
const ENV_PROJ = import.meta.env.VITE_FIREBASE_PROJECT_ID || auth?.app?.options?.projectId || '';

// Koleksi yang dibersihkan saat tenant dihapus (best-effort).
const PURGE_COLLECTIONS = [
  'produk', 'bahan', 'resep', 'orders', 'pos_history', 'kas_keluar',
  'supplier', 'riwayat_stok', 'self_orders', 'pengaturan', 'cabang',
  'karyawan', 'stations', 'absensi', 'payroll', 'pengajuan', 'dokumen',
  'audit_log', 'meja_sessions'
];

export const DeveloperPanel = () => {
  const [user, setUser] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [authLoading, setAuthLoading] = useState(false);
  const [authErr, setAuthErr] = useState('');
  const [storeName, setStoreName] = useState('');
  const [tenantId, setTenantId] = useState('');
  const [password, setPassword] = useState('');
  const [ownerPin, setOwnerPin] = useState('');
  const [ownerEmail, setOwnerEmail] = useState('');
  const [licType, setLicType] = useState('BASIC');
  const [durVal, setDurVal] = useState(1);
  const [durUnit, setDurUnit] = useState('month');
  const [saving, setSaving] = useState(false);
  const toastTimer = useRef(null);
  const [clients, setClients] = useState([]);
  const [toast, setToast] = useState('');
  const [accessErr, setAccessErr] = useState('');
  const [copiedId, setCopiedId] = useState(null);
  // v15.1: kredensial tenant baru, tampil SEKALI di modal setelah simpan
  const [justMade, setJustMade] = useState(null);
  // v21.1.3: status tombol "coba kirim link verifikasi" di modal kredensial
  const [verifRetry, setVerifRetry] = useState(false);
  // v15.1: konfirmasi hapus 2 langkah + status proses
  const [confirmDel, setConfirmDel] = useState(null);
  const [delBusy, setDelBusy] = useState(false);

  // ===== FITUR CUSTOM APLIKASI (white-label) =====
  // Perusahaan yang mau custom bisa request ke developer. Developer
  // memilih tenant di sini, menyalakan custom, menaruh logo perusahaan,
  // lalu memilih warna UI (merah/biru/hijau/kustom sesuai identitas).
  // Logo WELP otomatis diganti logo perusahaan + endorsement jadi "by WELP".
  const [cbTenant, setCbTenant] = useState('');
  const [cbForm, setCbForm] = useState({ aktif: false, namaPerusahaan: '', logo: null, warna: 'oren', warnaHex: '#E2483D' });
  const [cbBusy, setCbBusy] = useState(false);
  const [cbLogoBusy, setCbLogoBusy] = useState(false);

  useEffect(() => {
    if (!cbTenant) return;
    setCbBusy(true);
    getDoc(doc(db, 'tenants', cbTenant, 'pengaturan', 'branding'))
      .then(snap => {
        const d = snap.data();
        setCbForm(d ? {
          aktif: !!d.aktif, namaPerusahaan: d.namaPerusahaan || '', logo: d.logo || null,
          warna: d.warna || 'oren', warnaHex: d.warnaHex || '#E2483D'
        } : { aktif: false, namaPerusahaan: '', logo: null, warna: 'oren', warnaHex: '#E2483D' });
      })
      .catch(() => showToast('Gagal memuat konfigurasi custom tenant ini.'))
      .finally(() => setCbBusy(false));
  }, [cbTenant]);

  const pickCbLogo = async (file) => {
    if (!file) return;
    setCbLogoBusy(true);
    try {
      const logoUrl = await fileToDataUrl(file, 480, 0.8);
      setCbForm(f => ({ ...f, logo: logoUrl }));
    }
    catch (e) { showToast('Gagal memuat logo: ' + (e.message || 'coba lagi')); }
    setCbLogoBusy(false);
  };

  const previewBrand = () => {
    // Pratinjau langsung terasa di console: logo & warna berubah sebelum disimpan.
    // Kustom mati → kembali ke tampilan WELP biasa.
    writeBrandMirror(cbForm.aktif ? { key: 'branding', ...cbForm } : null);
  };

  const saveCustom = async () => {
    if (!cbTenant) return showToast('Pilih tenant dulu.');
    if (cbForm.aktif && cbForm.warna === 'kustom' && !hexToTriplet(cbForm.warnaHex)) return showToast('Warna kustom tidak valid (format #RRGGBB).');
    setCbBusy(true);
    try {
      await setDoc(doc(db, 'tenants', cbTenant, 'pengaturan', 'branding'), {
        key: 'branding', ...cbForm,
        updatedAt: Date.now(), updatedBy: auth.currentUser ? auth.currentUser.email : 'developer'
      });
      showToast('Custom aplikasi tersimpan! Tenant langsung memakai identitas barunya.');
    } catch (e) { showToast('Gagal simpan: ' + explainStoreError(e), 8000); }
    setCbBusy(false);
  };

  // Kontrol tema dev: uji Light & Dark mode langsung dari panel.
  // Preferensi tersimpan di localStorage 'theme' (satu sumber dgn app).
  const [dark, setDark] = useState(() => {
    const saved = localStorage.getItem('theme');
    return saved ? saved === 'dark' : window.matchMedia('(prefers-color-scheme: dark)').matches;
  });
  useEffect(() => { document.documentElement.classList.toggle('dark', dark); }, [dark]);
  const toggleDark = () => {
    const nd = !dark; setDark(nd);
    localStorage.setItem('theme', nd ? 'dark' : 'light');
    document.documentElement.classList.toggle('dark', nd);
  };

  const showToast = (m, ms = 2600) => {
    setToast(m);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), ms);
  };

  useEffect(() => {
    // Robustness: bila Firebase gagal init, jangan panggil onAuthStateChanged(null).
    if (!auth) { setAuthReady(true); return; }
    const unsub = onAuthStateChanged(auth, (u) => { setUser(u); setAuthReady(true); });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!user) return;
    const qy = query(collection(db, 'licenses'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(qy, (snap) => { setAccessErr(''); setClients(snap.docs.map((d) => ({ ...d.data(), id: d.id }))); }, (err) => setAccessErr('Akun ini tidak punya izin admin (cek Firestore Rules): ' + err.code));
    return () => unsub();
  }, [user]);

  useEffect(() => {
    const base = storeName.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 12);
    setTenantId(base);
  }, [storeName]);

  // Pesan error auth yang bisa ditindaklanjuti. "auth/invalid-credential" mentah
  // bikin bingung: Firebase sengaja menyamarkan "user tidak ada" & "password
  // salah" jadi kode yang sama (anti user-enumeration) sejak 2023.
  const explainAuthError = (e) => {
    const code = e?.code || '';
    const proj = ENV_PROJ || auth?.app?.options?.projectId || 'project aktif';
    switch (code) {
      case 'auth/invalid-credential':
      case 'auth/wrong-password':
      case 'auth/user-not-found':
        return `Email atau password salah, ATAU akun developer belum ada di project "${proj}" (Firebase menyamarkan keduanya, jadi tidak bisa dibedakan dari sini). Langkah perbaikan: (1) Firebase Console → project ${proj} → Authentication → Sign-in method → pastikan Email/Password aktif; (2) tab Users → Add user dengan email developer ini; (3) kalau akun sudah ada tapi lupa password → reset dari tab Users; (4) verifikasi email developer (tab Users → titik tiga → verifikasi) supaya allowlist isDev di rules mengenalinya.`;
      case 'auth/operation-not-allowed':
        return `Provider Email/Password belum diaktifkan di project "${proj}". Buka Firebase Console → Authentication → Sign-in method → Email/Password → Enable, lalu coba lagi.`;
      case 'auth/too-many-requests':
        return 'Terlalu banyak percobaan login gagal, Firebase memblokir sementara. Tunggu beberapa menit, atau reset password akun ini dari Firebase Console → Authentication → Users.';
      case 'auth/network-request-failed':
        return 'Koneksi ke Firebase gagal. Periksa internet/VPN/DNS, lalu coba lagi.';
      case 'auth/invalid-email':
        return 'Format email tidak valid. Periksa penulisan email developer.';
      case 'auth/invalid-api-key':
      case 'auth/api-key-not-valid.-please-pass-a-valid-api-key.':
        return `API key Firebase kosong/tidak valid di build ini. Penyebab paling umum: file .env tidak ada di folder ROOT project (harus sejajar package.json, BUKAN di dalam functions/), atau .env dibuat SETELAH aplikasi di-build (env hanya dibaca saat dev-server start / npm run build). Perbaiki .env di root, lalu restart npm run dev / jalankan ulang npm run build. Nilai API key diambil dari Firebase Console → Project settings → General → Web app (project ${proj}).`;
      case 'auth/admin-restricted-operation':
        return 'Operasi dibatasi pengaturan project. Pastikan domain aplikasi terdaftar di Authentication → Settings → Authorized domains.';
      default:
        return 'Login gagal: ' + (code || e?.message || 'kesalahan tidak diketahui');
    }
  };

  // v21.1.3: penjelas error callable/server + Firestore. Dulu client hanya
  // menampilkan "internal" telanjang bila server crash, sekarang server
  // memetakan error (mapAdminError), dan sisa kasus klien dijelaskan di sini.
  const explainFnError = (e) => {
    const code = String(e?.code || '').replace(/^functions\//, '');
    const raw = String(e?.message || '').trim();
    if (code === 'internal') {
      return 'Server functions bermasalah saat memproses. CATATAN PLAN GRATIS: plan Spark tidak bisa deploy Cloud Functions, v21.2 sudah tidak membutuhkannya untuk fitur panel ini. Jika pesan ini muncul, kamu memakai build lama: update ke v21.2+. Detail teknis: npx firebase functions:log.';
    }
    if (code === 'not-found') {
      return 'Backend functions tidak terpasang di project ini, WAJAR di plan gratis (Spark, functions butuh Blaze). Kabar baiknya: v21.2 sudah berjalan tanpa functions. Pesan ini berarti kamu masih memakai build lama, pakai v21.2 atau lebih baru.';
    }
    if (code === 'wrong-existing-password') return raw || 'Email sudah terdaftar dengan password berbeda.';
    if (code === 'weak-password' || code === 'auth/weak-password') return raw || 'Password terlalu lemah, pakai tombol Acak (huruf besar/kecil, angka, simbol).';
    if (code === 'operation-not-allowed' || code === 'auth/operation-not-allowed') return 'Provider Email/Password belum aktif. Firebase Console → Authentication → Sign-in method → Enable Email/Password, lalu ulangi.';
    if (code === 'unauthenticated') return 'Sesi developer kedaluwarsa. Keluar, login lagi, lalu ulangi simpan.';
    if (code === 'permission-denied') {
      return (raw || 'Rules Firestore menolak akses ini.') + ' Periksa: (1) email developer TERVERIFIKASI & tercantum di allowlist isDev/isProvisioner di file rules; (2) rules terbaru sudah di-publish (firebase deploy --only firestore:rules, ini bisa di plan gratis); (3) App Check terpasang (VITE_RECAPTCHA_SITE_KEY di .env) bila rules menuntut request.app.';
    }
    if (code === 'already-exists') return raw || 'Data dengan ID tersebut sudah ada.';
    if (code === 'unavailable' || code === 'deadline-exceeded' || code === 'resource-exhausted') return 'Server sibuk atau tidak terjangkau (' + code + '). Coba lagi beberapa saat.';
    if (code === 'cancelled') return 'Permintaan dibatalkan sebelum selesai. Coba lagi.';
    if (raw) return raw; // pesan server sudah berbahasa Indonesia (HttpsError)
    return code || 'Kesalahan tidak diketahui.';
  };
  // v21.1.3: penjelas error Firestore (penulisan dokumen langsung).
  const explainStoreError = (e) => {
    const code = String(e?.code || '').replace(/^functions\//, '');
    if (code === 'permission-denied') return 'Rules Firestore menolak penyimpanan ini. Publish rules terbaru (firebase deploy --only firestore:rules), pastikan email developer terverifikasi, dan (mode enterprise) App Check terpasang.';
    if (code === 'unavailable' || code === 'deadline-exceeded') return 'Firestore tidak terjangkau sementara (jaringan). Coba lagi.';
    if (code === 'internal') return 'Firestore bermasalah sementara (internal). Coba lagi; bila terus, cek status.firebase.com.';
    if (code === 'resource-exhausted') return 'Kuota Firestore project ini habis/terbatas. Periksa billing & kuota di console.';
    if (code === 'unauthenticated') return 'Sesi login kedaluwarsa. Keluar lalu login lagi.';
    return e?.message || code || 'Kesalahan tidak diketahui.';
  };

  const doLogin = async () => {
    if (!email || !pass) { setAuthErr('Isi email & password developer.'); return; }
    setAuthErr(''); setAuthLoading(true);
    try { await signInWithEmailAndPassword(getAuth(), email.trim(), pass); }
    catch (e) { setAuthErr(explainAuthError(e)); }
    setAuthLoading(false);
  };
  const doLogout = () => signOut(getAuth());

  // v21.1.3: PRNG kripto (Math.random = Mersenne-Twister, state-nya bisa
  // dipulihkan dari output, bukan untuk materi kredensial).
  // Kelas karakter LENGKAP (besar/kecil/angka/simbol): lolos password
  // policy ketat sekalipun + entropi ±93^12 (jauh di atas 62^10 lama).
  const genPass = () => {
    const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    const lower = 'abcdefghijkmnpqrstuvwxyz';
    const digits = '23456789';
    const syms = '!@#$%&*';
    const all = upper + lower + digits + syms;
    const rnd = new Uint32Array(24);
    crypto.getRandomValues(rnd);
    const p = [upper[rnd[0] % upper.length], lower[rnd[1] % lower.length], digits[rnd[2] % digits.length], syms[rnd[3] % syms.length]];
    for (let i = 4; i < 12; i++) p.push(all[rnd[i] % all.length]);
    for (let i = p.length - 1; i > 0; i--) { const j = rnd[12 + i] % (i + 1); [p[i], p[j]] = [p[j], p[i]]; }
    setPassword(p.join(''));
  };
  const genPin = () => {
    const rnd = new Uint32Array(6);
    crypto.getRandomValues(rnd);
    setOwnerPin(Array.from(rnd, n => String(n % 10)).join(''));
  };

  const saveTenant = async () => {
    if (!storeName || !tenantId || !password || !ownerPin || !ownerEmail) return showToast('Nama toko, email owner, password, PIN, dan ID tenant wajib diisi!');
    // v15.2: kebijakan kredensial, PIN 6 digit & password min. 8 char
    // (PIN pendek = brute-force offline murah walau pakai PBKDF2).
    if (!/^\d{6}$/.test(ownerPin)) return showToast('Owner PIN wajib tepat 6 digit angka (pakai tombol Acak).');
    if (password.length < 8) return showToast('Password minimal 8 karakter (pakai tombol Acak).');
    if (!/^\S+@\S+\.\S+$/.test(ownerEmail.trim())) return showToast('Email owner tidak valid.');
    if (!/^[a-z0-9._-]{3,}$/i.test(tenantId)) return showToast('ID Tenant min. 3 karakter: huruf/angka/._- tanpa spasi.');
    setSaving(true);
    const date = new Date();
    if (durUnit === 'month') date.setMonth(date.getMonth() + Number(durVal));
    if (durUnit === 'year') date.setFullYear(date.getFullYear() + Number(durVal));
    if (durUnit === 'day') date.setDate(date.getDate() + Number(durVal));
    try {
      // v15 F0: kredensial owner disimpan sebagai HASH (PBKDF2-SHA256,
      // salt acak), password & ownerPin plaintext tidak pernah ditulis
      // ke Firestore. CATAT kredensial ini di tempat aman: setelah
      // tersimpan, tidak bisa dilihat lagi dari panel ini.
      const credPass = await makeCred(password);
      const credPin = await makeCred(ownerPin);
      const email = ownerEmail.trim().toLowerCase();
      const tid = tenantId.toLowerCase();
      const store = storeName; // dipakai setelah form di-reset
      // v21.2, PROVISIONING 100% KLIEN (TIDAK BUTUH CLOUD FUNCTIONS).
      // Dulu: createWelpIdentity via functions → plan Spark tidak bisa
      // deploy functions → endpoint tidak ada → "Gagal simpan: internal".
      // Kini: (1) akun Auth dibuat/dipakai via app sekunder + email
      // verifikasi terkirim otomatis, (2) lisensi, (3) identitas di
      // welp_identities/{uid}, HANYA developer allowlist yang boleh
      // menulisnya (rules), setara keamanan claims server, (4) record
      // karyawan owner utk linking Employee Area.
      const identity = await provisionWelpIdentityClient({ email, password, continueUrl: window.location.origin + window.location.pathname });
      await setDoc(doc(db, 'licenses', tid), {
        id: tid, credPass, credPin, tenant: store, type: licType,
        active: true, validUntil: date.toISOString(), createdAt: new Date().toISOString(),
        ownerEmail: email, authVersion: 2,
        createdBy: auth.currentUser ? auth.currentUser.email : 'unknown'
      });
      const ownerPerms = [
        'dashboard.read','sales.read','sales.write','sales.refund','inventory.read','inventory.write','inventory.adjust',
        'employee.read','employee.write','attendance.read','attendance.write','payroll.read','payroll.write','payroll.approve',
        'finance.read','finance.write','reports.read','settings.read','settings.write','audit.read','company.manage','branch.manage'
      ];
      await setDoc(doc(db, 'welp_identities', identity.uid), {
        uid: identity.uid, email, tenant: tid, role: 'owner', branch: null,
        department: null, permissions: ownerPerms, regions: [], branches: [],
        scope: 'org', disabled: false, authVersion: 2,
        createdAt: new Date().toISOString(),
        createdBy: auth.currentUser ? auth.currentUser.email : 'unknown'
      });
      const ownerCid = 'akun-' + String(identity.uid).replace(/[^a-zA-Z0-9]/g, '').slice(0, 24);
      await setDoc(doc(db, 'tenants', tid, 'karyawan', ownerCid), {
        cid: ownerCid, uid: identity.uid, empId: 'OWNER',
        name: 'Owner ' + store, email, role: 'owner', branchId: 'PUSAT',
        branchIds: [], regionIds: [], status: 'aktif', department: null,
        jenisKontrak: 'tetap', tenantId: tid, authAccount: true,
        provisionedAt: Date.now()
      }, { merge: true });
      // v21.2: email verifikasi sudah OTOMATIS dikirim saat langkah (1).
      // verifWarn hanya terisi bila kirim email gagal (domain belum di
      // Authorized domains), tombol kirim ulang ada di modal ini.
      setJustMade({
        id: tid, tenant: store, email, pass: password, pin: ownerPin,
        verificationSent: identity.verificationSent, verifWarn: identity.verificationSent ? '' : 'Email verifikasi gagal terkirim otomatis. Pastikan domain halaman ini terdaftar di Firebase Console → Authentication → Settings → Authorized domains, lalu tekan tombol kirim ulang di bawah.',
        createdAccount: identity.created, uid: identity.uid
      });
      setStoreName(''); setTenantId(''); setPassword(''); setOwnerPin(''); setOwnerEmail('');
    } catch (e) { showToast('Gagal simpan: ' + explainFnError(e), 9000); }
    setSaving(false);
  };

  // v21.2: kirim ulang email verifikasi owner TANPA functions, masuk
  // sebagai owner di app sekunder (password tersedia di modal kredensial),
  // kirim email, keluar. Sesi developer utama tidak pernah tersentuh.
  const retryVerification = async () => {
    if (!justMade?.email || verifRetry) return;
    setVerifRetry(true);
    try {
      await welpResendVerification({ email: justMade.email, password: justMade.pass, continueUrl: window.location.origin + window.location.pathname });
      setJustMade((m) => ({ ...m, verificationSent: true, verifWarn: '' }));
      showToast('Email verifikasi terkirim ke owner!');
    } catch (e) { showToast('Masih gagal: ' + explainFnError(e), 9000); }
    setVerifRetry(false);
  };
  const toggleStatus = (id, status) => updateDoc(doc(db, 'licenses', id), { active: status }).catch((e) => showToast('Gagal ubah status: ' + explainStoreError(e), 8000));

  // v15.1: bersih-bersih data tenants/{lic} (best-effort), lisensi tetap
  // dihapus dulu sebagai operasi kritis; kegagalan purge tidak membatalkan.
  const purgeTenantData = async (lic) => {
    let total = 0;
    for (const col of PURGE_COLLECTIONS) {
      try {
        const snap = await getDocs(collection(db, 'tenants', lic, col));
        if (snap.empty) continue;
        let batch = writeBatch(db), n = 0;
        snap.docs.forEach((d) => { batch.delete(d.ref); n++; total++; if (n % 400 === 0) { batch.commit().catch(() => {}); batch = writeBatch(db); n = 0; } });
        if (n > 0) await batch.commit();
      } catch (e) { /* lanjut koleksi berikutnya */ }
    }
    return total;
  };

  const delTenant = async (id) => {
    if (!devVerified) return showToast('Hanya email developer terverifikasi yang boleh menghapus tenant (rules v15.2).');
    if (confirmDel !== id) {
      // langkah 1: arming, tombol berubah merah 4 detik
      setConfirmDel(id);
      setTimeout(() => setConfirmDel((c) => (c === id ? null : c)), 4000);
      return;
    }
    // langkah 2: eksekusi
    setConfirmDel(null); setDelBusy(true);
    try {
      await deleteDoc(doc(db, 'licenses', id));
      const purged = await purgeTenantData(id).catch(() => -1);
      showToast(purged >= 0
        ? 'Tenant ' + id + ' dihapus permanen (±' + purged + ' data dibersihkan).'
        : 'Tenant ' + id + ' dihapus. Sebagian data riwayat gagal dibersihkan (aman diabaikan).');
    } catch (e) {
      showToast('Gagal hapus: ' + (e.code || e.message)
        + (e.code === 'permission-denied' ? '. Publish rules v15.2 dan verifikasi email dev dulu.' : ''));
    }
    setDelBusy(false);
  };
  const copyText = (txt, id) => { navigator.clipboard.writeText(txt); setCopiedId(id); showToast('Disalin!'); setTimeout(() => setCopiedId(null), 1500); };

  const daysLeft = (iso) => Math.max(0, Math.ceil((new Date(iso) - new Date()) / 864e5));

  // v15.1: status developer utk UI, email di allowlist & terverifikasi
  const devEmail = user ? String(user.email || '').toLowerCase() : '';
  const devListed = !!devEmail && DEV_EMAILS.includes(devEmail);
  const devVerified = devListed && user.emailVerified === true;

  /* ---- v9.1: verifikasi email yang tidak bikin frustrasi ----
   * Fakta Firebase: link verifikasi SEKALI pakai, dan hanya link
   * TERBARU yang valid (kirim ulang = link lama mati). Status
   * emailVerified di sesi juga TIDAK update sendiri, butuh
   * reload() + refresh token supaya rules ikut percaya. */
  const [resendCd, setResendCd] = useState(0);
  const [busyVerif, setBusyVerif] = useState(false);
  const [, bumpStatus] = useReducer((x) => x + 1, 0);

  useEffect(() => {
    if (resendCd <= 0) return undefined;
    const t = setTimeout(() => setResendCd((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [resendCd]);

  const refreshDevStatus = async () => {
    if (busyVerif) return;
    setBusyVerif(true);
    try {
      const u = getAuth().currentUser;
      if (!u) return;
      await u.reload();
      await u.getIdToken(true); // paksa token baru → claim email_verified terbarui utk rules
      bumpStatus();
      showToast(u.emailVerified
        ? 'Status: TERVERIFIKASI. Badge DEV hijau aktif.'
        : 'Masih belum terverifikasi. Buka email TERBARU, klik link-nya SATU kali saja.');
    } catch (e) {
      showToast('Gagal cek status: ' + (e.code || e.message));
    }
    setBusyVerif(false);
  };

  const kirimVerifikasi = async () => {
    if (busyVerif || resendCd > 0) return;
    setBusyVerif(true);
    try {
      await sendEmailVerification(user, {
        url: window.location.origin + window.location.pathname,
        handleCodeInApp: false,
      });
      setResendCd(45);
      showToast('Terkirim. Buka email paling atas, cukup sekali. Link lama otomatis mati.');
    } catch (e) {
      showToast('Gagal kirim: ' + (e.code || e.message)
        + (e.code === 'too-many-requests' ? ', terlalu sering. Tunggu beberapa menit.' : ''));
    }
    setBusyVerif(false);
  };

  // v9.1: balik dari link verifikasi (halaman hosted Firebase me-redirect
  // ke panel dengan ?mode=verifyEmail&oobCode=...) → refresh otomatis.
  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    if (p.get('mode') !== 'verifyEmail' || !p.get('oobCode') || !authReady) return;
    (async () => {
      try {
        try { await applyActionCode(getAuth(), p.get('oobCode')); } catch (_) { /* kode mungkin sudah dipakai halaman hosted, cek status saja */ }
        const u = getAuth().currentUser;
        if (u) { await u.reload().catch(() => {}); await u.getIdToken(true).catch(() => {}); }
        window.history.replaceState({}, '', window.location.pathname);
        bumpStatus();
        showToast(u && u.emailVerified ? 'Email developer terverifikasi ✓' : 'Verifikasi diproses. Tekan Cek Status bila badge belum hijau.');
      } catch (_) { /* diam */ }
    })();
  }, [authReady]);

  if (!authReady) {
    return <div className="min-h-screen bg-paper dark:bg-chrome-deep flex items-center justify-center"><div className="spinner-ring"></div></div>;
  }

  /* ---------------- LOGIN SCREEN ---------------- */
  if (!user) {
    return (
      <div className="min-h-screen bg-paper dark:bg-chrome-deep flex items-center justify-center p-4 relative overflow-hidden">
        <div className="absolute -top-32 -left-32 w-96 h-96 bg-flame-200/50 dark:bg-flame-500/15 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-[#E9ECF1]/90 dark:bg-apricot/10 rounded-full blur-3xl"></div>
        {/* kontrol tema: dev bisa uji light/dark sebelum login */}
        <button onClick={toggleDark} aria-label="Ganti tema" className="absolute top-4 right-4 w-10 h-10 rounded-full bg-surface dark:bg-white/5 border border-line dark:border-chrome-edge text-ink-faint dark:text-ink-inv/60 flex items-center justify-center transition">
          {dark ? <Terang className="w-4.5 h-4.5" /> : <Gelap className="w-4.5 h-4.5" />}
        </button>
        <div className="relative w-full max-w-sm bg-surface dark:bg-chrome-panel/90 backdrop-blur-xl border border-line dark:border-chrome-edge rounded-3xl p-7 shadow-pop animate-rise">
          <div className="flex flex-col items-center mb-6">
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-flame-400 to-flame-600 flex items-center justify-center shadow-card mb-3">
              <AppSymbol className="w-10 h-10 text-white" />
            </div>
            <h1 className="font-display text-ink dark:text-ink-inv font-extrabold text-lg">WELP Developer Console</h1>
            <p className="text-[10px] text-ink-faint dark:text-ink-inv/40 font-bold uppercase tracking-[0.2em] mt-1">by JUSTru Group</p>
            <p className="text-[11px] text-ink-faint dark:text-ink-inv/50 font-bold mt-2 flex items-center gap-1.5"><PerisaiBuddy className="w-4 h-4 text-flame-500" /> Area terbatas, khusus developer</p>
            {!ENV_KEY_OK ? (
              <div className="w-full text-brick-deep text-[11px] font-bold bg-brick-soft border border-brick/20 rounded-2xl p-3 leading-relaxed text-left flex items-start gap-2 mb-2"><BahayaBuddy className="w-4 h-4 shrink-0 mt-0.5" /><span><b>Config .env belum terbaca oleh build ini</b>, VITE_FIREBASE_API_KEY kosong, login pasti gagal. Taruh file <b>.env</b> di folder ROOT project (sejajar package.json, BUKAN di dalam functions/), lalu <b>restart npm run dev</b> / <b>build ulang</b>. Catatan: functions/.env hanya butuh WELP_BOOTSTRAP_EMAILS, API key tidak ditaruh di sana.</span></div>
            ) : (
              <p className="text-[10px] font-mono text-ink-faint dark:text-ink-inv/45 bg-paper dark:bg-white/5 border border-line dark:border-chrome-edge rounded-full px-3 py-1 mt-2" title="Login ini divalidasi terhadap project Firebase yang tercantum, kalau akun developer lu ada di project lain, pindahkan .env atau buat akunnya di sini">project: {ENV_PROJ || '-'}</p>
            )}
            {ENV_KEY_OK && firebaseInitError && (
              <div className="w-full text-brick-deep text-[11px] font-bold bg-brick-soft border border-brick/20 rounded-2xl p-3 leading-relaxed text-left flex items-start gap-2 mb-2"><BahayaBuddy className="w-4 h-4 shrink-0 mt-0.5" /><span>Firebase gagal inisialisasi: {String(firebaseInitError?.message || firebaseInitError)}</span></div>
            )}
          </div>
          <div className="space-y-3">
            <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="Email developer" className="w-full bg-paper dark:bg-chrome-deep/80 border border-line dark:border-chrome-edge text-ink dark:text-ink-inv text-sm font-bold p-3.5 rounded-2xl outline-none focus:border-flame-400 transition" />
            <input value={pass} onChange={(e) => setPass(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && doLogin()} type="password" placeholder="Password" className="w-full bg-paper dark:bg-chrome-deep/80 border border-line dark:border-chrome-edge text-ink dark:text-ink-inv text-sm font-bold p-3.5 rounded-2xl outline-none focus:border-flame-400 transition" />
            {authErr && <div className="text-brick-deep text-[11px] font-bold bg-brick-soft border border-brick/20 rounded-2xl p-3 leading-relaxed text-left flex items-start gap-2"><BahayaBuddy className="w-4 h-4 shrink-0 mt-0.5" /> <span>{authErr}</span></div>}
            <button onClick={doLogin} disabled={authLoading} className="w-full py-3.5 rounded-2xl bg-flame-600 hover:bg-flame-500 text-white font-extrabold text-sm flex items-center justify-center gap-2 disabled:opacity-60 press shadow-card">{authLoading ? <span className="spinner-ring !border-white/30 !border-t-white"></span> : <><GembokBuddy className="w-4 h-4" /> Masuk Console</>}</button>
          </div>
          <p className="text-[10px] text-ink-faint dark:text-ink-inv/40 text-center mt-5 leading-relaxed">Login memakai Firebase Authentication (Email/Password). Buat akun developer di Firebase Console terlebih dahulu.</p>
        </div>
      </div>
    );
  }

  /* ---------------- CONSOLE ---------------- */
  const activeCount = clients.filter(c => c.active).length;
  const suspendCount = clients.length - activeCount;
  const proCount = clients.filter(c => c.type === 'PRO' || c.type === 'PREMIUM').length;
  const stats = [
    { label: 'Tenant', value: clients.length, icon: MonitorPusat, tone: 'text-flame-700 dark:text-apricot' },
    { label: 'Aktif', value: activeCount, icon: PerisaiBuddy, tone: 'text-leaf-deep dark:text-leaf' },
    { label: 'Suspend', value: suspendCount, icon: BahayaBuddy, tone: 'text-brick' },
    { label: 'PRO', value: proCount, icon: Lisensi, tone: 'text-gold-deep dark:text-gold' },
  ];

  return (
    <div className="min-h-screen bg-paper dark:bg-chrome-deep text-ink dark:text-ink-inv pb-24">
      {/* header gradasi */}
      <nav className="sticky top-0 z-30 bg-gradient-to-r from-flame-600 via-flame-500 to-flame-600 px-4 py-3.5 shadow-pop">
        <div className="max-w-3xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur text-white flex items-center justify-center"><MonitorPusat className="w-5.5 h-5.5" /></div>
            <div>
              <h1 className="font-display font-extrabold text-sm leading-none text-white flex items-center gap-2">Developer Console
                {devListed && <span className={`text-[8.5px] px-2 py-0.5 rounded-full font-extrabold ${devVerified ? 'bg-leaf text-white' : 'bg-white/25 text-white'}`}>{devVerified ? 'DEV' : 'DEV?'}</span>}
              </h1>
              <p className="text-[10px] text-white/70 font-bold mt-1">{user.email}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={toggleDark} aria-label="Ganti tema" className="w-9 h-9 rounded-2xl bg-white/15 hover:bg-white/25 text-white flex items-center justify-center transition press">
              {dark ? <Terang className="w-4.5 h-4.5" /> : <Gelap className="w-4.5 h-4.5" />}
            </button>
            <button onClick={doLogout} className="text-[11px] font-extrabold text-white/90 bg-white/15 hover:bg-white/25 px-4 py-2.5 rounded-2xl transition press">Keluar</button>
          </div>
        </div>
      </nav>

      <div className="max-w-3xl mx-auto px-4 pt-6 space-y-6">
        {accessErr && <div className="bg-brick-soft dark:bg-brick/15 border border-brick/30 text-brick-deep dark:text-brick text-[11px] font-bold p-3.5 rounded-2xl flex items-start gap-2"><BahayaBuddy className="w-4 h-4 shrink-0 mt-0.5" /> {accessErr}</div>}

        {/* v15 F0: peringatan rules, sesi anonymous belum tersedia */}
        {anonAuthBlocked() && (
          <div className="bg-gold-soft dark:bg-gold/10 border border-gold/40 text-gold-deep dark:text-gold text-[11px] font-bold p-3.5 rounded-2xl leading-relaxed">
            <p className="flex items-start gap-2"><BahayaBuddy className="w-4 h-4 shrink-0 mt-0.5" /> Sesi ANONIM Firebase belum aktif. Sebelum publish rules v15: Firebase Console → Authentication → Sign-in method → aktifkan <b>Anonymous</b>. Sampai itu dilakukan, app tetap jalan dengan rules lama (kurang ketat).</p>
          </div>
        )}

        {/* v15.1 + v9.1: email dev terdaftar tapi belum verifikasi */}
        {devListed && !devVerified && (
          <div className="bg-gold-soft dark:bg-gold/10 border border-gold/40 text-gold-deep dark:text-gold text-[11px] font-bold p-3.5 rounded-2xl leading-relaxed">
            <p className="flex items-start gap-2"><BahayaBuddy className="w-4 h-4 shrink-0 mt-0.5" /> Email {user.email} ada di allowlist tapi <b>belum terverifikasi</b>. Verifikasi dulu supaya hapus tenant diizinkan rules v15.2.</p>
            <p className="mt-2 text-[10px] font-bold opacity-80 leading-relaxed">Link Firebase sekali pakai dan kirim ulang mematikan link lama. Jadi klik link di email <b>paling atas</b> (terbaru), <b>satu kali saja</b>, di tab browser biasa. Kalau link selalu tertulis "sudah digunakan", besar kemungkinan emailmu sebenarnya SUDAH terverifikasi sejak klik pertama: langsung tekan <b>Cek Status</b>.</p>
            <div className="mt-2.5 flex flex-wrap gap-2">
              <button onClick={kirimVerifikasi} disabled={busyVerif || resendCd > 0}
                className="px-3.5 py-2 rounded-xl bg-gold/90 hover:bg-gold text-white text-[10.5px] font-extrabold press disabled:opacity-50">
                {resendCd > 0 ? 'Kirim ulang (' + resendCd + 's)' : 'Kirim email verifikasi'}
              </button>
              <button onClick={refreshDevStatus} disabled={busyVerif}
                className="px-3.5 py-2 rounded-xl border border-gold/60 text-gold-deep dark:text-gold text-[10.5px] font-extrabold press disabled:opacity-50">
                {busyVerif ? 'Memeriksa…' : 'Cek Status'}
              </button>
            </div>
          </div>
        )}
        {user && !devListed && (
          <div className="bg-gold-soft dark:bg-gold/10 border border-gold/40 text-gold-deep dark:text-gold text-[11px] font-bold p-3.5 rounded-2xl leading-relaxed">
            <p className="flex items-start gap-2"><BahayaBuddy className="w-4 h-4 shrink-0 mt-0.5" /> Email ini <b>tidak ada di allowlist developer</b> ({DEV_EMAILS.join(', ')}). Daftar/suspend tetap bisa, tapi hapus tenant hanya utk developer terverifikasi.</p>
          </div>
        )}

        {/* stat ringkas */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {stats.map(s => (
            <div key={s.label} className="bg-surface dark:bg-chrome-panel border border-line dark:border-chrome-edge rounded-3xl p-4 shadow-card">
              <s.icon className={`w-6 h-6 mb-2 ${s.tone}`} />
              <p className="text-2xl font-extrabold money leading-none text-ink dark:text-ink-inv">{s.value}</p>
              <p className="kicker mt-1.5">{s.label}</p>
            </div>
          ))}
        </div>

        {/* registrasi tenant */}
        <div className="bg-surface dark:bg-chrome-panel/70 border border-line dark:border-chrome-edge rounded-[1.6rem] p-5 shadow-card">
          <h2 className="font-extrabold text-base mb-4 flex items-center gap-2"><Lisensi className="w-5.5 h-5.5 text-flame-600 dark:text-apricot" /> Registrasi Tenant</h2>
          <div className="space-y-3">
            <div>
              <label className="kicker block mb-1 ml-0.5">Nama Client / Toko</label>
              <input value={storeName} onChange={(e) => setStoreName(e.target.value)} placeholder="Contoh: Kopi Senja" className="field" />
            </div>
            <div>
              <label className="kicker block mb-1 ml-0.5">ID Tenant (username login)</label>
              <input value={tenantId} onChange={(e) => setTenantId(e.target.value)} className="field lowercase" />
            </div>
            <div>
              <label className="kicker block mb-1 ml-0.5">Email Owner</label>
              <input value={ownerEmail} onChange={(e) => setOwnerEmail(e.target.value)} type="email" placeholder="owner@perusahaan.com" className="field" autoComplete="email" />
              <p className="text-[10px] text-ink-faint mt-1.5 font-bold">Dipakai sebagai identitas login WELP. Email wajib diverifikasi sebelum akun dapat masuk.</p>
            </div>
            <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <label className="kicker block mb-1 ml-0.5">Password</label>
                <div className="flex gap-2">
                  <input value={password} onChange={(e) => setPassword(e.target.value)} className="field flex-1 min-w-0 font-mono" />
                  <button onClick={genPass} className="px-3 rounded-xl bg-flame-50 dark:bg-flame-900/40 text-flame-700 dark:text-apricot text-xs font-extrabold border border-flame-200 dark:border-flame-500/30 press">Acak</button>
                </div>
              </div>
              <div>
                <label className="kicker block mb-1 ml-0.5">Owner PIN (6 digit)</label>
                <div className="flex gap-2">
                  <input value={ownerPin} onChange={(e) => setOwnerPin(e.target.value)} className="field flex-1 min-w-0 font-mono" />
                  <button onClick={genPin} className="px-3 rounded-xl bg-brick-soft dark:bg-brick/15 text-brick text-xs font-extrabold border border-brick/30 press">Acak</button>
                </div>
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <label className="kicker block mb-1 ml-0.5">Durasi Sewa</label>
                <div className="flex gap-2">
                  <input type="number" value={durVal} onChange={(e) => setDurVal(e.target.value)} className="field w-16" />
                  <select value={durUnit} onChange={(e) => setDurUnit(e.target.value)} className="field flex-1 min-w-0 bg-surface dark:bg-surface-dark"><option value="day">Hari</option><option value="month">Bulan</option><option value="year">Tahun</option></select>
                </div>
              </div>
              <div>
                <label className="kicker block mb-1 ml-0.5">Tipe Lisensi</label>
                <div className="grid grid-cols-2 gap-1.5 p-1 bg-paper dark:bg-white/5 rounded-xl">
                  {['BASIC', 'PRO'].map(tp => (
                    <button key={tp} onClick={() => setLicType(tp)} className={`py-2 rounded-lg text-[11px] font-extrabold transition press ${licType === tp ? 'bg-flame-500 text-white shadow-card' : 'text-ink-faint'}`}>{tp}</button>
                  ))}
                </div>
              </div>
            </div>
            <button onClick={saveTenant} disabled={saving} className="w-full py-3.5 rounded-2xl bg-flame-600 hover:bg-flame-500 text-white font-extrabold text-sm flex items-center justify-center gap-2 disabled:opacity-60 mt-1 press shadow-card">{saving ? <span className="spinner-ring !border-white/30 !border-t-white"></span> : <><Check className="w-4 h-4" /> Simpan ke Firebase</>}</button>
          </div>
        </div>

        {/* FITUR CUSTOM APLIKASI (white-label) */}
        <div className="bg-surface dark:bg-chrome-panel/70 border border-line dark:border-chrome-edge rounded-[1.6rem] p-5 shadow-card">
          <h2 className="font-extrabold text-base mb-1 flex items-center gap-2"><Toko className="w-5.5 h-5.5 text-flame-600 dark:text-apricot" /> Custom Aplikasi</h2>
          <p className="text-[11px] text-ink-faint dark:text-ink-inv/50 font-semibold leading-relaxed mb-4">
            Perusahaan yang mau tampilan sendiri cukup request ke developer. Nyalakan custom di tenantnya, taruh logo perusahaan, dan pilih warna UI sesuai identitasnya. Logo WELP berganti jadi logo perusahaan, dan tulisan pengembangnya jadi "by WELP".
          </p>
          <div className="space-y-3">
            <div>
              <label className="kicker block mb-1 ml-0.5">Pilih Tenant</label>
              <select value={cbTenant} onChange={(e) => setCbTenant(e.target.value)} className="field bg-surface dark:bg-surface-dark">
                <option value="">pilih tenant</option>
                {clients.map(c => <option key={c.id} value={c.id}>{c.tenant} ({c.id})</option>)}
              </select>
            </div>
            {cbTenant && !cbBusy && (
              <>
                <button onClick={() => setCbForm(f => ({ ...f, aktif: !f.aktif }))}
                  className={`w-full flex items-center justify-between gap-3 p-3.5 rounded-2xl border transition press ${cbForm.aktif ? 'bg-flame-50 dark:bg-flame-900/25 border-flame-200 dark:border-flame-500/40' : 'bg-paper dark:bg-white/5 border-line dark:border-chrome-edge'}`}>
                  <span className="text-left">
                    <span className="block text-[12.5px] font-extrabold text-ink dark:text-ink-inv">Custom aktif</span>
                    <span className="block text-[10px] font-semibold text-ink-faint">Tampilan tenant ini memakai identitas perusahaannya</span>
                  </span>
                  <span className={`w-11 h-6 rounded-full p-0.5 transition-all shrink-0 ${cbForm.aktif ? 'bg-flame-600' : 'bg-line dark:bg-white/15'}`}>
                    <span className={`block w-5 h-5 rounded-full bg-white shadow transition-transform ${cbForm.aktif ? 'translate-x-5' : ''}`} />
                  </span>
                </button>
                <div>
                  <label className="kicker block mb-1 ml-0.5">Logo Perusahaan</label>
                  {cbForm.logo ? (
                    <div className="flex items-center gap-3 p-3 rounded-2xl bg-paper dark:bg-white/5 border border-line dark:border-chrome-edge">
                      <img src={cbForm.logo} alt="Logo perusahaan" className="h-12 w-auto max-w-[160px] object-contain" />
                      <div className="flex gap-2 ml-auto">
                        <label className="px-3 py-2 rounded-xl bg-surface dark:bg-white/5 border border-line dark:border-chrome-edge text-[10.5px] font-extrabold text-ink-soft dark:text-ink-inv/70 cursor-pointer press">Ganti
                          <input type="file" accept="image/*" className="hidden" onChange={e => pickCbLogo(e.target.files[0])} />
                        </label>
                        <button onClick={() => setCbForm(f => ({ ...f, logo: null }))} className="px-3 py-2 rounded-xl bg-brick-soft dark:bg-brick/10 text-brick text-[10.5px] font-extrabold press">Hapus</button>
                      </div>
                    </div>
                  ) : (
                    <label className="flex flex-col items-center justify-center py-6 border-2 border-dashed border-line dark:border-chrome-edge rounded-2xl cursor-pointer hover:border-flame-400 transition">
                      {cbLogoBusy ? <><span className="spinner-ring"></span><p className="text-[10px] font-bold text-ink-faint mt-1.5">Memproses logo...</p></> : <>
                        <Toko className="w-7 h-7 text-ink-faint/50 mb-1.5" />
                        <p className="text-[11px] font-extrabold text-ink-soft dark:text-ink-inv/70">Upload logo perusahaan</p>
                        <p className="text-[9px] text-ink-faint font-semibold mt-0.5">PNG/JPG, dikompres otomatis, transparan paling bagus</p>
                      </>}
                      <input type="file" accept="image/*" className="hidden" onChange={e => pickCbLogo(e.target.files[0])} />
                    </label>
                  )}
                </div>
                <div>
                  <label className="kicker block mb-1 ml-0.5">Nama Perusahaan (opsional)</label>
                  <input value={cbForm.namaPerusahaan} onChange={e => setCbForm(f => ({ ...f, namaPerusahaan: e.target.value }))} placeholder="Contoh: Kopi Senja" className="field" />
                </div>
                <div>
                  <label className="kicker block mb-1 ml-0.5">Warna UI / UX</label>
                  <div className="grid grid-cols-5 gap-1.5">
                    {['oren', 'merah', 'biru', 'hijau', 'kustom'].map(w => (
                      <button key={w} onClick={() => setCbForm(f => ({ ...f, warna: w }))}
                        className={`py-2 rounded-xl text-[10px] font-extrabold capitalize border-2 transition press ${cbForm.warna === w ? 'border-flame-500 bg-flame-50 dark:bg-flame-900/25 text-flame-700 dark:text-apricot' : 'border-line dark:border-chrome-edge text-ink-faint'}`}>
                        {w}
                      </button>
                    ))}
                  </div>
                  {cbForm.warna === 'kustom' && (
                    <div className="flex items-center gap-2 mt-2">
                      <input type="color" value={cbForm.warnaHex} onChange={e => setCbForm(f => ({ ...f, warnaHex: e.target.value }))} className="w-11 h-11 rounded-xl border border-line dark:border-chrome-edge bg-transparent cursor-pointer" />
                      <input value={cbForm.warnaHex} onChange={e => setCbForm(f => ({ ...f, warnaHex: e.target.value }))} className="field flex-1 min-w-0 font-mono" placeholder="#RRGGBB" />
                      <span className="w-11 h-11 rounded-xl border border-line dark:border-chrome-edge shrink-0" style={{ backgroundColor: cbForm.warnaHex }} />
                    </div>
                  )}
                </div>
                <div className="flex gap-2">
                  <button onClick={saveCustom} className="flex-1 py-3.5 rounded-2xl bg-flame-600 hover:bg-flame-500 text-white font-extrabold text-sm flex items-center justify-center gap-2 press shadow-card"><Check className="w-4 h-4" /> Simpan Custom</button>
                  <button onClick={previewBrand} className="px-4 py-3.5 rounded-2xl bg-paper dark:bg-white/5 border border-line dark:border-chrome-edge text-ink-soft dark:text-ink-inv/70 font-extrabold text-sm press">Pratinjau</button>
                </div>
                <p className="text-[9.5px] text-ink-faint dark:text-ink-inv/40 font-semibold text-center">Pratinjau berlaku di console ini saja. Tekan Simpan supaya tenant ikut berubah. Matikan custom untuk kembali ke tampilan WELP biasa.</p>
              </>
            )}
            {cbTenant && cbBusy && <p className="text-[11px] font-bold text-ink-faint text-center py-3">Memuat konfigurasi...</p>}
          </div>
        </div>

        {/* daftar tenant */}
        <div>
          <h2 className="font-extrabold text-base mb-3 flex items-center gap-2 px-1"><KoinBuddy className="w-5.5 h-5.5 text-flame-600 dark:text-apricot" /> Daftar Tenant <span className="text-[11px] font-bold text-ink-faint">({clients.length})</span></h2>
          <div className="space-y-3">
            {clients.length === 0 && (
              <div className="text-center py-12">
                <Mascot pose="pikir" className="w-20 h-20 object-contain mx-auto mb-2 opacity-80" alt="" />
                <p className="text-xs font-bold text-ink-faint">Belum ada client. Daftarkan tenant pertama di atas.</p>
              </div>
            )}
            {clients.map((c) => (
              <div key={c.id} className="bg-surface dark:bg-chrome-panel/70 border border-line dark:border-chrome-edge rounded-3xl p-4.5 shadow-card">
                <div className="flex justify-between items-start mb-3">
                  <div className="min-w-0">
                    <h4 className="font-extrabold text-sm flex items-center gap-2 text-ink dark:text-ink-inv">{c.tenant}
                      <span className={`text-[9px] px-2 py-0.5 rounded-full font-extrabold ${c.type === 'PRO' || c.type === 'PREMIUM' ? 'bg-gold-soft dark:bg-gold/15 text-gold-deep dark:text-gold' : 'bg-flame-50 dark:bg-flame-900/40 text-flame-700 dark:text-apricot'}`}>{c.type}</span>
                    </h4>
                    <p className="text-[10px] text-ink-faint dark:text-ink-inv/50 mt-1 font-semibold flex items-center gap-1.5">
                      <Kredensial className="w-3.5 h-3.5" /> ID: <span className="font-extrabold text-flame-700 dark:text-apricot">{c.id}</span>
                      <span className="text-ink-faint">s/d {new Date(c.validUntil).toLocaleDateString('id-ID')} ({daysLeft(c.validUntil)} hari)</span>
                    </p>
                  </div>
                  <span className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[9px] font-extrabold shrink-0 ${c.active ? 'text-leaf-deep dark:text-leaf bg-leaf-soft dark:bg-leaf/10' : 'text-brick bg-brick-soft dark:bg-brick/10'}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${c.active ? 'bg-leaf animate-pulse-dot' : 'bg-brick'}`} />
                    {c.active ? 'AKTIF' : 'SUSPEND'}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 mb-3">
                  {/* v15 F0: kredensial tenant tersimpan hash, tidak ada lagi
                      copy password/PIN dari panel. Status ditampilkan saja. */}
                  <div className="bg-paper dark:bg-chrome-deep/70 border border-line dark:border-chrome-edge p-2.5 rounded-xl flex justify-between items-center">
                    <span className="text-[9px] font-extrabold text-ink-faint flex items-center gap-1"><GembokBuddy className="w-3.5 h-3.5" /> PASS</span>
                    <span className="font-mono font-extrabold text-[10px] text-leaf-deep dark:text-leaf flex items-center gap-1">{c.credPass ? <><Check className="w-3 h-3" /> ter-hash</> : (c.password ? 'legacy plaintext' : '-')}</span>
                  </div>
                  <div className="bg-brick-soft dark:bg-brick/10 p-2.5 rounded-xl flex justify-between items-center">
                    <span className="text-[9px] font-extrabold text-brick">PIN</span>
                    <span className="font-mono font-extrabold text-[10px] text-brick flex items-center gap-1">{c.credPin ? <><Check className="w-3 h-3" /> ter-hash</> : (c.ownerPin ? 'legacy plaintext' : '-')}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  {c.active
                    ? <button onClick={() => toggleStatus(c.id, false)} className="flex-1 py-2.5 rounded-xl bg-brick-soft dark:bg-white/5 border border-brick/30 text-brick text-[11px] font-extrabold press">Suspend</button>
                    : <button onClick={() => toggleStatus(c.id, true)} className="flex-1 py-2.5 rounded-xl bg-flame-600 hover:bg-flame-500 text-white text-[11px] font-extrabold press">Buka Akses</button>}
                  {/* v15.1: hapus = khusus dev terverifikasi, konfirmasi 2 langkah */}
                  <button onClick={() => delTenant(c.id)} disabled={delBusy} aria-label="Hapus tenant"
                    title={devVerified ? 'Hapus tenant (2× klik)' : 'Hanya email developer terverifikasi'}
                    className={`w-11 rounded-xl flex items-center justify-center transition press border ${confirmDel === c.id ? 'bg-brick border-brick text-white animate-pulse-dot' : 'bg-paper dark:bg-white/5 border-line dark:border-chrome-edge text-ink-faint hover:text-brick'} disabled:opacity-50`}>
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                {confirmDel === c.id && (
                  <p className="text-[10px] font-extrabold text-brick mt-2 flex items-center gap-1.5"><BahayaBuddy className="w-3.5 h-3.5" /> Tekan sekali lagi untuk hapus permanen. Lisensi dan data tenants/{c.id} dibersihkan.</p>
                )}
              </div>
            ))}
          </div>
        </div>

        <p className="text-center text-[9px] font-extrabold text-ink-faint dark:text-ink-inv/25 uppercase tracking-[0.2em] flex items-center justify-center gap-1.5"><WaktuReal className="w-3.5 h-3.5" /> WELP Developer Console v21.2.0 · Spark-ready</p>
      </div>
      {toast && <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 bg-flame-600 text-white px-5 py-3 rounded-full shadow-pop text-sm font-extrabold animate-slide-up">{toast}</div>}

      {/* v15.1: modal KREDENSI TAMPAK SEKALI setelah registrasi tenant */}
      {justMade && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-center justify-center p-4" onClick={(e) => { if (e.target === e.currentTarget) setJustMade(null); }}>
          <div className="w-full max-w-sm bg-surface dark:bg-chrome-panel border border-line dark:border-chrome-edge rounded-3xl p-6 shadow-pop animate-rise">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-11 h-11 rounded-2xl bg-leaf-soft dark:bg-leaf/15 text-leaf-deep dark:text-leaf flex items-center justify-center shrink-0"><Check className="w-6 h-6" /></div>
              <div>
                <h3 className="font-extrabold text-ink dark:text-ink-inv text-sm">Tenant "{justMade.tenant}" terdaftar!</h3>
                <p className="text-[10px] text-ink-faint font-bold">Salin & kirim kredensial ini ke client sekarang</p>
              </div>
            </div>
            <div className="space-y-2.5 mb-4">
              {[
                { label: 'Email Owner', val: justMade.email, key: 'email' },
                { label: 'ID Tenant', val: justMade.id, key: 'id' },
                { label: 'Password', val: justMade.pass, key: 'pass' },
                { label: 'Owner PIN', val: justMade.pin, key: 'pin' }
              ].map(r => (
                <div key={r.key} className="flex items-center gap-2 p-3 rounded-2xl bg-paper dark:bg-white/5 border border-line dark:border-chrome-edge">
                  <div className="min-w-0 flex-1">
                    <p className="kicker mb-0.5">{r.label}</p>
                    <p className="font-mono font-extrabold text-sm text-flame-700 dark:text-apricot tracking-wider truncate">{r.val}</p>
                  </div>
                  <button onClick={() => copyText(r.val, 'jm-' + r.key)} aria-label="Salin" className="w-9 h-9 rounded-xl bg-surface dark:bg-white/5 border border-line dark:border-chrome-edge text-ink-faint hover:text-flame-600 dark:hover:text-apricot flex items-center justify-center shrink-0 transition press">
                    {copiedId === 'jm-' + r.key ? <Check className="w-4 h-4 text-leaf-deep dark:text-leaf" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              ))}
            </div>
            <p className="text-[10px] text-brick font-extrabold flex items-start gap-1.5 mb-4 leading-relaxed"><BahayaBuddy className="w-4 h-4 shrink-0 mt-0.5" /> Ini SATU-SATUNYA kali kredensial tampil. Setelah modal ditutup, tersimpan sebagai hash dan tidak bisa dilihat lagi.</p>
            {justMade.verificationSent ? <div className="mb-4 p-3 rounded-2xl bg-leaf-soft dark:bg-leaf/10 border border-leaf/30">
              <p className="kicker mb-1">Verifikasi email owner</p>
              <p className="text-[10px] font-bold text-ink-faint leading-relaxed">Email verifikasi SUDAH OTOMATIS terkirim ke <span className="text-ink dark:text-ink-inv font-extrabold">{justMade.email}</span>. Owner cukup buka email → klik link verifikasi → login via mode <b>Akun WELP</b> (email + password di atas). Tanpa Cloud Functions.</p>
            </div> : null}
            {justMade.verifWarn && <div className="mb-4 p-3 rounded-2xl bg-gold-soft dark:bg-gold/10 border border-gold/30">
              <p className="text-[10px] font-bold text-gold-deep dark:text-gold leading-relaxed flex items-start gap-1.5"><BahayaBuddy className="w-4 h-4 shrink-0 mt-0.5" /><span><b>Email verifikasi belum terkirim.</b> {justMade.verifWarn}</span></p>
              <button onClick={retryVerification} disabled={verifRetry} className="mt-2 w-full py-2 rounded-xl bg-gold text-white text-[10px] font-extrabold press disabled:opacity-60">{verifRetry ? 'Mencoba…' : 'Kirim ulang email verifikasi'}</button>
            </div>}
            <button onClick={() => setJustMade(null)} className="w-full py-3 rounded-2xl bg-flame-600 hover:bg-flame-500 text-white font-extrabold text-sm press shadow-card">Saya sudah catat & salin</button>
          </div>
        </div>
      )}
    </div>
  );
};
