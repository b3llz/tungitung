# LAPORAN PENILAIAN & MASTER CHANGE PLAN — WELP v14 (Fondasi v15)

Tanggal: 23 September 2026 · Status: TAHAP PENILAIAN — TIDAK ADA KODE DIUBAH
Metode: pembacaan menyeluruh 21 file source (±12.300 baris), firestore.rules, config, index.css;
verifikasi runtime (dist v14 di-serve, viewport 320/390/1366, data seed lokal, Firestore produksi
diblokir agar terisolasi); bukti diberikan sebagai file:line atau screenshot di `download/audit-shots/`.

Legenda severity: **K = Kritis, T = Tinggi, S = Sedang, R = Rendah**.
Tanda [FAKTA] = terbukti dari kode/behavior. [REK] = rekomendasi improvement.

---

## 1. PETA ARSITEKTUR SAAT INI (pemahaman sistem)

- **Stack**: Vite + React 18 SPA, Tailwind 3 (design token via CSS variable `--fl-*` untuk white-label), Firebase JS SDK langsung dari browser (Firestore + Auth — Auth hanya dipakai Developer Panel). Tanpa backend server; satu-satunya "backend enforcement" adalah Firestore Security Rules.
- **Routing**: query-param (`?dev=panel`, `?absen=1&lic=`, `?meja=&lic=&k=`); tanpa router. Tab utama = state `active` dengan pola keep-alive (semua tab selalu ter-mount, disembunyikan via CSS) — App.jsx:191-216.
- **Sumber data TERBAGI DUA** (split-brain):
  - Firestore `tenants/{lic}/…`: cabang, karyawan, absensi, payroll, pengajuan, pengaturan, dokumen, stations, audit_log, self_orders, meja_sessions — via `useTenantCol` (core.jsx:240) realtime + mirror localStorage.
  - **localStorage SAJA**: produk, bahan baku, resep HPP, transaksi POS (pos_history_db), pesanan aktif, kas keluar, supplier, riwayat stok, profil toko, konfigurasi pajak/diskon, mode bisnis, meja (mapping key lengkap ada di lampiran audit).
- **Identitas**: Owner = ID toko + password (plaintext di doc `licenses`) + ownerPin 6 digit. Cabang = password cabang shared + PIN cabang shared → role sesuai doc cabang. Karyawan (app ?absen=1) = ID toko → pilih cabang → PIN cabang → pilih nama → PIN pribadi. POS Station = ID toko + kode station + PIN station (role kasir, isStation).
- **Session**: JSON `app_license` di localStorage (password/ownerPin di-strip, `_branchList` TIDAK), validUntil dicek vs jam perangkat, monitoring lisensi via onSnapshot.
- **Role**: 3 (owner/admin/kasir), dipakai untuk menyembunyikan menu (shell.jsx NAV_GROUPS) + scope filter client-side. Tidak ada permission granular.

---

## 2. TEMUAN — KEAMANAN & AUTHENTICATION (prioritas tertinggi)

| ID | Sev | Temuan & bukti | Dampak |
|----|-----|----------------|--------|
| A1 | **K** | [FAKTA] Rules `tenants/{lic}/{document=**}` mengizinkan read/create/update **tanpa `request.auth`** — cukup lisensi aktif (firestore.rules:62-75). Semua data tenant (password cabang, PIN karyawan plaintext, foto absensi, payroll, dokumen HR) bisa dibaca/ditulis siapa pun yang tahu lic, bahkan tanpa login. | Kebocoran total; manipulasi payroll/absensi dari luar app; IDOR penuh; seluruh "authorization" app hanya kosmetik. |
| A2 | **K** | [FAKTA] `licenses/{id}` `allow get: if true` + password owner & ownerPin disimpan **plaintext** di doc (devpanel.jsx saveTenant; diverifikasi lock.jsx:130,156). ID = slug nama toko ≤12 char (devpanel) → mudah ditebak/enumerasi. | Siapa pun dapat kredensial owner dengan satu `getDoc`. |
| A3 | **K** | [FAKTA] Login mode Cabang: `_branchList` (berisi password+PIN cabang plaintext) ikut masuk `app_license` di localStorage — strip di lock.jsx:164 & App.jsx:116 hanya top-level `password/ownerPin`, `_branchList` lolos. | Kredensial semua cabang tersimpan plaintext di perangkat; bisa diekstrak. |
| A4 | **T** | [FAKTA] Semua verifikasi PIN/password client-side terhadap data yang bisa dibaca langsung dari Firestore (karena A1). Tidak ada rate limit / lockout percobaan PIN (lock.jsx, absensi-app checkPin/checkPin2, pos.jsx StationKasirGate). | Brute-force PIN 6 digit praktis tanpa hambatan. |
| A5 | **T** | [FAKTA] Sesi = JSON localStorage tanpa tanda tangan; role/branchId/employeeCid bisa diedit bebas; filter data client-side (`employeeCid === session.employeeCid`); validUntil pakai jam perangkat. | Role escalation & branch hopping total dari DevTools. |
| A6 | **S** | [FAKTA] Jalur login legacy `employee_db` dari localStorage (lock.jsx:159) — kredensial di klien, tidak tersinkron, kontradiksi dengan model karyawan Firestore. | Jalur akses usang & tidak konsisten. |
| A7 | **S** | [FAKTA] auditLog actor/role dikirim dari klien (core.jsx:560-573); siapa pun bisa menulis audit_log palsu (karena A1). | Audit trail tidak dapat dipercaya — perlu ditulis dengan identity terverifikasi. |
| A8 | **S** | [FAKTA] `syncSession` memakai timestamp klien & mengambil IP via api.ipify.org tiap heartbeat (core.jsx:116-130). | Inkonsisten dengan kebijakan serverTimestamp; ketergantungan pihak ketiga. |
| A9 | **S** | [FAKTA] Data keluar ke pihak ketiga: quickchart.io (isi slip & QRIS), CDN ExcelJS/SheetJS tanpa SRI (core.jsx:144-163). | Kebocoran data ringan; risiko supply-chain. |
| A10 | **S** | [FAKTA] Backup/Restore menyalin seluruh localStorage termasuk `app_license` (settings.jsx:586-609) → file backup bisa diforging untuk membuat sesi palsu; backup berisi data sensitif tanpa enkripsi. | Vektor sesi palsu + data sensitif berpindah tanpa perlindungan. |
| A11 | **R** | [FAKTA] `makeTableToken`/`getDeviceId` pakai `Math.random()` (core.jsx:222-232). | Token sesi meja prediktabel secara teori. |

**Kesimpulan inti**: arsitektur authorization saat ini TIDAK mampu memenuhi target "backend memastikan user hanya mengakses datanya". Perlu identitas server-side (Firebase Auth per karyawan + custom claims) dan rules yang mengecek auth + relasi, bukan hanya lisensi aktif. Ini perubahan paling berisiko — dikerjakan pertama dengan rencana migrasi khusus.

---

## 3. TEMUAN — LOGIN KARYAWAN & BRANCH CONTEXT

| ID | Sev | Temuan & bukti | Dampak |
|----|-----|----------------|--------|
| C1 | **T** | [FAKTA] Karyawan masih WAJIB tahu PIN cabang (shared) sebelum bisa memilih nama & PIN pribadi (absensi-app.jsx:105-129); app utama mode Cabang memakai password+PIN cabang shared utk semua staf (lock.jsx:120-152). Target "karyawan punya akun pribadi, tanpa credential cabang" BELUM terpenuhi. | Kredensial beredar luas; tanggung jawab tidak personal. |
| C2 | **T** | [FAKTA] Branch auto-detection dari relasi data TIDAK ada: semua cabang tenant ditampilkan (step cabang `branches.map` semua — absensi-app.jsx:210); `karyawan.branchId` tunggal (team.jsx) → karyawan multi-cabang tidak didukung; tidak ada pemilihan cabang berbasis hak akses. | Bertentangan dengan requirement; owner/admin yang pegang 2 cabang tidak terlayani. |
| C3 | **S** | [FAKTA] Akun tanpa PIN bisa dipakai langsung dengan memilih nama (absensi-app pickEmployee `if (!e.pin) finish`); POS Station "Lanjut sebagai {nama}" tanpa PIN (pos.jsx:464-468). | Penyalahgunaan identitas antar rekan kerja. |
| C4 | **S** | [FAKTA] Friction: 5 langkah login absensi; tidak ada reset PIN oleh karyawan yang lupa (hanya owner regen di Manajemen Karyawan); tidak ada "ingat ID toko/cabang" selain preLic dari QR/link. | Friction harian tinggi di depan kasir. |
| C5 | **R** | [FAKTA] Beberapa pencocokan memakai NAMA karyawan (AbsensiTab todayRows by name+branch:1159-1160; rekap:1012; payroll periodWork fallback). | Dua karyawan senama di cabang sama = data tercampur. |

---

## 4. TEMUAN — ROLE & PERMISSION

| ID | Sev | Temuan & bukti | Dampak |
|----|-----|----------------|--------|
| D1 | **T** | [FAKTA] Permission = menu hiding frontend saja (shell.jsx:27-57) + flag per tab; nol enforcement backend (A1). Belum ada permission granular (lihat daftar di brief). | Semua role sebenarnya setara di tingkat data. |
| D2 | **S** | [FAKTA] `isOwner = sessionRole !== 'admin'` di PayrollTab (team.jsx:1488) → role apa pun selain admin (termasuk kasir, mis. lewat state yang diubah) diperlakukan owner; tidak ada route/component guard. | Pemisahan wewenang payroll bocor di level UI. |
| D3 | **S** | [FAKTA] Role Owner bisa dibuat bebas dari Manajemen Karyawan tanpa konfirmasi/batas (team.jsx:630-631); karyawan ber-role owner langsung dapat panel approval seluruh cabang di app absensi. | Peningkatan wewenang tanpa kontrol. |
| D4 | [REK] Rancang permission matrix (keys: dashboard.view, employee.manage, branch.manage, attendance.manage, attendance.correct, payroll.manage, payroll.view, product.manage, inventory.manage, purchasing.manage, refund.perform, report.financial, qris.manage, settings.manage, role.manage, audit.view) + role bawaan (Owner, Direktur, Manager, Supervisor, Admin, Kasir, HR, Finance, Inventory) yang di-mapping ke permission — bukan daftar menu. Role ekstra hanya untuk bisnis yang butuh. |

---

## 5. TEMUAN — WATERMARK & IMAGE HANDLING

| ID | Sev | Temuan & bukti | Dampak |
|----|-----|----------------|--------|
| E1 | **T** | [FAKTA] Watermark absensi = band teks + kotak huruf "W" di-canvas (stampAbsenPhoto core.jsx:472-554). Belum mendukung **logo perusahaan sebagai image watermark** (opacity, ukuran, posisi, aspect ratio, safe area, logo transparan/ber-background) sesuai target brief. | Gap fitur vs kebutuhan; identitas foto belum memakai logo asli. |
| E2 | **S** | [FAKTA] Kompresi berlapis: kamera JPEG 0.8 (absensi-app shoot:363) → stamp re-encode 0.72 (core.jsx:549). Foto 720px cukup jelas, tapi degradasi kumulatif & tidak ada pilihan kualitas. | Kualitas foto turun; tidak ada kontrol storage vs clarity. |
| E3 | **S** | [FAKTA] EXIF orientation mengandalkan default browser (`<img>` decode); tidak ada `createImageBitmap` dengan `imageOrientation` eksplisit. Di webview lama bisa miring. | Risiko foto miring di sebagian perangkat Android lama. |
| E4 | **R** | [FAKTA] Fallback `ctx.roundRect` → `fillRect` (kotak tajam); font watermark Arial (bukan brand font). | Konsistensi visual antar browser. |
| E5 | [REK] "Pilih Foto" dari galeri memperbolehkan foto apa pun (tanpa liveness) — keterbatasan yang wajar, tapi perlu dikomunikasikan di UI agar watermark tidak memberi rasa aman berlebih. |

---

## 6. TEMUAN — GEOLOCATION

| ID | Sev | Temuan & bukti | Dampak |
|----|-----|----------------|--------|
| F1 | **T** | [FAKTA] Submit absen WAJIB geo (`disabled={!photo || !geo}` absensi-app.jsx:486) → izin ditolak / GPS gagal / desktop tanpa GPS = karyawan tidak bisa absen sama sekali; tidak ada jalur alternatif berflag. | Karyawan valid tidak bisa absen — dampak bisnis langsung (payroll harian terpengaruh). |
| F2 | **S** | [FAKTA] Tidak ada reverse geocoding sama sekali (hanya koordinat mentah di stamp & monitoring). Brief meminta alamat manusiawi (jalan/kecamatan/kota/provinsi) + tetap simpan koordinat & accuracy asli. | Monitoring owner sulit dibaca; kebutuhan fitur belum ada. |
| F3 | **R** | [FAKTA] `getLocation` sekali coba, timeout 12s, tanpa retry/watcher untuk akurasi lebih baik; tidak ada penanganan khusus accuracy rendah. | Kegagalan capture lebih sering dari yang seharusnya. |

---

## 7. TEMUAN — QRIS

| ID | Sev | Temuan & bukti | Dampak |
|----|-----|----------------|--------|
| G1 | **T** | [FAKTA] `decodeQrFromImage` hanya memakai `BarcodeDetector` (core.jsx:353-365) — tidak tersedia di Safari iOS & Firefox → upload foto QRIS tidak terbaca otomatis di iPhone; hanya fallback tempel payload manual (copy-nya pun mengakui "Chrome/Edge"). | Fitur utama pembayaran gagal di sebagian besar iPhone. |
| G2 | **S** | [FAKTA] Validasi payload minim: hanya cek tag 00/01 (settings.jsx:358-365); CRC-16 tag 63 TIDAK diverifikasi (padahal `crc16CCITT` sudah ada di core.jsx); metadata merchant (tag 59/60) tidak dibaca/disimpan; statis vs dinamis tidak dibedakan terstruktur; payload disimpan sebagai string di `store_profile` (device-lokal). | Payload rusak/palsu bisa lolos; data merchant tidak terpakai. |
| G3 | **S** | [FAKTA] Gambar dikompres 900px/0.72 SEBELUM decode (settings saveQrisImage → decodeQrFromImage) — kompresi dapat merusak QR; decode jalan di main thread (bisa jank di HP low-end). | Angka keberhasilan decode turun. |
| G4 | **R** | [FAKTA] Tidak ada penyaringan payload issuer (QRID/ID/EMVCo pattern) — payload arbitrer bisa ditempel; dampak rendah (QR hanya ditampilkan) tapi tetap perlu validasi dasar. | Risiko kecil, mudah dimitigasi. |
| G5 | [FAKTA, positif] Builder QRIS dinamis EMVCo (sisip tag 54, flag 12, CRC) sudah benar (core.jsx:173-215) — dipertahankan. |

---

## 8. TEMUAN — UI/UX (yang terverifikasi runtime; screenshot: download/audit-shots/)

| ID | Sev | Temuan & bukti | Dampak |
|----|-----|----------------|--------|
| H1 | **T** | [FAKTA, diukur] Ikon tanda tanya (HelpBox) **terpotong/tak terlihat** pada card berjudul panjang: `h3.truncate` membungkus `{title} {help && <HelpBox/>}` (ui.jsx:75). Terukur di 320px: "Shift Kerja Cabang Pusat" h3=136px tapi icon berada di x=241 (di luar area); "POS Station (Perangkat Kasir)" idem. | Help tidak bisa diakses di mobile — informasi penting hilang. Akar masalah: trigger di dalam elemen truncate, BUKAN soal positioning popup (popup-nya sudah centered aman). |
| H2 | **S** | [FAKTA, diukur 320px] Keypad PIN "Acak" terpotong (scrollWidth 40 vs clientWidth 30) — PinDots `grid-cols-6` + gap + padding card melebihi lebar konten 320px; grid Aturan Absensi ikut kepotong 6px. Ini akar nyata "card jam masuk/PIN overflow" di Manajemen Cabang — bukan soal overflow:hidden. | Tombol susah ditekan di layar kecil. |
| H3 | **S** | [FAKTA] `formatNumberDisplay` pemisah ribuan KOMA (core.jsx:57) sementara `formatIDR` memakai id-ID (TITIK): input "150,000" vs tampilan "Rp150.000". | Inkonsisten untuk pengguna Indonesia; rawan salah baca nominal. |
| H4 | **S** | [FAKTA] Pencarian POS hanya mencari nama produk (pos.jsx:803) padahal placeholder "Ketik SKU / Nama Produk...". | Copy tidak sesuai perilaku; pencarian SKU gagal. |
| H5 | **T** | [FAKTA] `viewport-fit=cover` TIDAK ada di index.html:8 → `env(safe-area-inset-bottom)` selalu 0 → `.pb-safe`/`.h-safe-nav` (index.css:71-72) tidak berfungsi; bottom nav menempel gesture bar iPhone. | Di iPhone, tombol bottom nav tertutup home indicator. |
| H6 | **S** | [FAKTA] Listener scanner USB global aktif selama app hidup (tab keep-alive; settings.jsx:149-157) → mengetik + Enter di halaman lain memunculkan toast palsu "Kode terbaca: …". | Toast mengganggu; perilaku tak terduga. |
| H7 | **S** | [FAKTA] Statistik "Belum Absen" menghitung karyawan nonaktif (staffScope tanpa filter status — team.jsx:995,1000). | Angka monitoring keliru. |
| H8 | **S** | [FAKTA] Payroll: tidak ada cegah duplikat karyawan+periode; picker periode hanya bulan tahun berjalan (team.jsx PERIODE) → tidak bisa membuat payroll periode lampau (bayar Desember di Januari mustahil). | Gaji ganda / kebuntuan pembayaran periode lampau. |
| H9 | **R** | [FAKTA] `paidAt = Date.now()` perangkat (team.jsx:1624) padahal toast mengklaim "dikunci waktu server"; slip menampilkan paidAt. | Klaim tidak akurat; waktu bayar bisa bias. |
| H10 | **S** | [FAKTA-kode] Buka dokumen/surat via `<a href={dataURL} target="_blank">` (PerusahaanTab:2202; EmpProfil letters) — Chrome modern memblokir navigasi top-frame ke data: URL (perlu konfirmasi di perangkat; untuk `target=_blank` sebagian versi masih lolos). [REK] Pakai Blob URL. | "Buka PDF di Tab Baru"/"Lihat surat" berpotensi mati di Chrome. |
| H11 | **R** | [FAKTA] `lateMin/lateStatus` absensi dihitung dari `Date.now()` perangkat saat submit (absensi-app doSubmit:1497) — `trustedNow()` tersedia tapi tidak dipakai; badge tampilan mengoreksi via serverAt, field mentah bisa bias. | Data telat mentah bisa dimanipulasi jam perangkat. |
| H12 | **S** | [FAKTA-kode] `Badge tone="grey"` dipakai di beberapa tempat (team.jsx:509, absensi StatusBadge) tapi map tone ui.jsx hanya punya neutral/green/gold/red/lime/teal → class `undefined`. | Badge tertentu tampil tanpa warna. |

---

## 9. TEMUAN — SELF-ORDER & FLOW F&B (temuan yang belum Anda sadari)

| ID | Sev | Temuan & bukti | Dampak |
|----|-----|----------------|--------|
| B2a | **K** | [FAKTA] Menu pelanggan dibaca dari localStorage **perangkat pelanggan** (selforder.jsx:25 `safeParse('product_stock_db')`, profil toko idem di App.jsx:248) → di HP pelanggan nyata menu & nama toko **kosong**. | Fitur self-order tidak berfungsi end-to-end untuk pelanggan eksternal. |
| B2b | **T** | [FAKTA] Siklus pesanan self-order putus: pesanan masuk Firestore `self_orders` (awaiting_validation) → validasi kasir membandingkan QR dengan `active_orders_db` LOKAL (pos.jsx:564-575) bukan Firestore, fallback "any pending" bisa memvalidasi pesanan salah → `confirmPayment` hanya menulis localStorage; dok Firestore tidak pernah diperbarui → status di HP pelanggan selamanya "Belum Divalidasi". | Alur F&B inti rusak; kepercayaan pelanggan jatuh. |

---

## 10. TEMUAN — PERFORMANCE, IA, DESIGN SYSTEM, COPY

- **J1 [FAKTA]** Keep-alive semua tab + onSnapshot banyak koleksi per tab (EmpHome 5 koleksi; AbsensiTab/OutletTab 6) → kuota read Firestore & memori membengkak; `useTenantCol` tanpa query server-side (seluruh koleksi ditarik, difilter klien).
- **J2 [FAKTA]** `enrich()`/`periodWork()` dihitung ulang tiap render tanpa memo penuh (AbsensiTab, PayrollTab) — O(n×k) pada data besar; EmpHome re-render per detik (jam) menarik ulang subtree.
- **J3 [FAKTA]** Foto/dokumen base64 inline di dokumen (B3): PDF 600KB → ~800KB base64 per dok, semua perangkat menarik semua foto saat listen koleksi. Perlu Firebase Storage (atau minimal lazy-load per doc).
- **J4 [REK]** Google Fonts 4 keluarga via @import (blocking) — self-host subset mempercepat first paint.
- **I1 [FAKTA]** Grup bisnis 11 menu (report, cabang, karyawan, absensi, payroll, perusahaan, outlet, profile, payment, hardware, settings) — keluarga "Pengaturan" (profile/payment/hardware/settings) bercampur operasional; Manajemen Cabang memuat 2 topik (kredensial cabang + POS Station + shift); nama internal `employee`=Cabang & `karyawan`=Karyawan rawan membingungkan pengembangan lanjutan.
- **I2 [FAKTA]** Routing query-param tanpa router — back button/refresh/deep link terbatas; untuk produk komersial perlu hash router.
- **I3 [REK]** Kelola Absensi memuat 4 subfitur dalam satu halaman panjang (monitoring, review cuti, QR login, rekap) — kandidat tab internal.
- **K1 [FAKTA-positif]** Design system kuat & konsisten: token warna via CSS var (white-label aman), dark mode menyeluruh, target WCAG didokumentasikan, prefers-reduced-motion dihormati, print CSS struk ada.
- **K2 [FAKTA]** `confirm()` native untuk aksi destruktif (hapus cabang/karyawan/dokumen/tenant, Reset Aplikasi yang MENGHAPUS SELURUH localStorage — satu-satunya salinan data komersial!) — tidak konsisten dengan sistem Modal dan terlalu ringan untuk risikonya.
- **K3 [FAKTA]** Copy secara umum sudah natural (bukan template-AI). Sisa kecil: teks role mentah 'owner' lowercase di footer sidebar (shell.jsx:127), istilah campur (Multi Outlet vs Cabang), beberapa "ya!" berlebihan. Pemilihan Bahasa EN di Pengaturan hanya menerjemahkan subset menu (i18n parsial) — menyesatkan.

---

## 11. YANG SUDAH BAIK (dipertahankan, jangan dirombak)

Slip gaji premium satu template shared (owner & karyawan) + logo custom + QR + approval; workflow payroll DRAFT→…→SELESAI dengan history; cuti policy 12 hari + override + validasi kuota; arsitektur white-label berbasis CSS variable (aman, tanpa rebuild); trusted-time (HEAD offset + serverTimestamp); builder QRIS dinamis EMVCo; selfie WYSIWYG mirror 3:4; offline mirror `useTenantCol`; print struk; error boundary; a11y motion.

---

## 12. MASTER CHANGE PLAN (urutan paling aman; setiap fase = build + verifikasi terpisah)

**Fase 0 — Fondasi Identity & Rules (prasyarat semua perubahan auth)**
1. Firebase Auth untuk semua orang: karyawan → akun ter-link (email-sintetis `{lic}.{empId}@welp.local` atau custom token), PIN di-hash (salt per user; verifikasi lewat Cloud Function / atau rules dgn hash field + auth.uid mapping di doc karyawan).
2. Rules v11: `tenants/{lic}/**` wajib `request.auth != null`; field `uid` di doc karyawan/station; claim role/branch via custom claims; helper `isAdmin()` tetap untuk dev. Migrasi data: field uid di-backfill oleh script owner/dev.
3. Hapus `_branchList` dari sesi; hapus jalur `employee_db`; strip semua credential dari apa pun yang masuk localStorage; rate-limit percobaan PIN (client throttle + lockout di doc percobaan, diperkuat Function bila ada).
Risiko: paling tinggi — butuh staging & backfill; kompatibilitas: mode login lama dipertahankan sebagai fallback terbatas hingga migrasi selesai.

**Fase 1 — Data komersial masuk Firestore** (products, raw_materials, recipes, orders, pos_history, expenses, suppliers, store settings) dengan import satu-kali dari localStorage + dual-write singkat; laporan/beranda/stok/ops dibaca dari Firestore. Fix B2a/B2b sekalian: menu self-order & profil toko dibaca tenant; validasi & pembayaran self-order ditulis ke Firestore.
Dependency: bisa jalan paralel dengan Fase 0 (beda domain) — mulai setelah Fase 0 tahap 2 agar rules siap.

**Fase 2 — Login karyawan baru & branch context**: akun pribadi murni (ID toko + identitas pribadi + PIN pribadi), auto-branch bila 1 relasi, branch picker berbasis hak bila >1 (field `branchIds[]` di karyawan), hapus PIN cabang dari alur karyawan, reset PIN oleh atasan dari app absensi (dengan audit).
Dependency: Fase 0 wajib selesai.

**Fase 3 — Permission granular & role**: matrix permission di `pengaturan/roles`; guard komponen + rules memvalidasi claim; UI Role & Permission manager (owner); perluasan role sesuai kebutuhan (Manager/Supervisor/HR/Finance/Inventory) — hanya mapping permission, tanpa menu baru.
Dependency: Fase 0; sebagian bisa paralel dengan Fase 2 akhir.

**Fase 4 — Perbaikan UI/UX terverifikasi** (independen, aman, cepat): H1 (keluarkan HelpBox dari h3.truncate), H2 (PinDots responsive), H3 (format id-ID), H4 (search SKU), H5 (viewport-fit=cover), H6 (scanner listener scoped), H7 (filter nonaktif), H8 (dedup periode + periode lampau), H9 (paidAt server), H12 (tone grey), confirm()→ConfirmDialog (termasuk Reset Aplikasi dgn konfirmasi ketik), tab internal Kelola Absensi, regroup menu Pengaturan, copy passes.
Dependency: tidak ada — bisa dieksekusi kapan pun (paling aman dilakukan lebih dulu untuk momentum).

**Fase 5 — Media & perangkat**: watermark logo image (opacity/posisi/ukuran/safe-area, dukung PNG transparan; konfigurasi per tenant), reverse geocoding (Nominatim via Function/proxy — key tidak menyentuh frontend; koordinat & accuracy asli tetap disimpan; fallback absen manual berflag utk F1), QRIS: fallback decoder jsQR/wasm + verifikasi CRC + metadata merchant tersimpan (G1-G4), dokumen besar → Firebase Storage.
Dependency: Fase 0 untuk storage rules; lainnya independen.

**Fase 6 — QA menyeluruh & rilis v15**: build, regression matrix per role/perangkat/viewport, uji 2-perangkat utk self-order & sinkronisasi stok, uji rules (simulator + attempt nyata), packaging zip.

---

## 13. CATATAN KEJUJURAN

- Tidak ada perubahan kode pada tahap ini. Runtime verifikasi memakai dist v14 + data seed lokal; Firestore produksi diblokir agar tidak menyentuh data nyata.
- Temuan yang butuh perangkat fisik untuk konfirmasi 100% (H10 data:URL di Chrome versi terbaru, E3 EXIF di webview lama) ditandai eksplisit — tidak dinyatakan "pasti rusak" tanpa bukti penuh.
- Estimasi dampak biaya Firestore (J1/J3) bersifat kualitatif berdasar pola baca; angka pasti butuh ukuran produksi.

**Status: TAHAP PENILAIAN SELESAI — menunggu izin Anda untuk masuk tahap eksekusi sesuai Master Change Plan.**
