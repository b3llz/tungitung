# PANDUAN DEPLOY WELP v15 — Security & Sync Overhaul

Tanggal: 23 September 2026 · Basis: WELP v14 → v15 (eksekusi Master Change Plan F0–F6)

---

## 0. RINGKASAN — APA YANG BERUBAH DI v15

| Fase | Perubahan | Dampak bagi pemakaian |
|------|-----------|----------------------|
| F0 | Kredensial (password owner, PIN cabang/station/karyawan, ownerPin) kini **hash PBKDF2** — plaintext tidak pernah tersimpan | Tidak ada tombol "lihat PIN" lagi — gunakan Acak/Ganti PIN; PIN baru ditampilkan **sekali** saat dibuat |
| F0 | Sesi localStorage **tanpa kredensial apapun** (termasuk _branchList) | Keamanan perangkat jauh lebih kuat; tidak ada perubahan alur login owner/cabang/station |
| F0 | **Rules v15**: semua akses Firestore wajib punya sesi Firebase Auth (anonim otomatis) + rate-limit PIN 5×/5 menit per perangkat | **WAJIB ikuti langkah 1–2 di bawah** sebelum publish rules |
| F1 | Data komersial (produk, bahan, resep, order, riwayat POS, kas keluar, supplier, riwayat stok, profil toko, pajak/diskon) **pindah ke Firestore** | Multi-device sinkron realtime; device pertama yang login setelah update **mengunggah data lokal otomatis**; pastikan HANYA satu device yang berisi data lama melakukan login pertama (lihat §3) |
| F1 | Self-order end-to-end: menu dari server, validasi & status pembayaran realtime ke HP pelanggan | QR meja & app pelanggan kini berfungsi untuk pelanggan sungguhan |
| F2 | **Login karyawan baru: ID Toko → Employee ID + PIN pribadi** (tanpa PIN cabang); multi-cabang = pilih cabang saat login; reset PIN oleh atasan dari app | Bagikan Employee ID ke tim; karyawan tanpa PIN harus diatur dulu PIN-nya oleh owner |
| F3 | Permission granular 14 hak × 9 role + editor **Role & Hak Akses** di Manajemen Karyawan | Owner bisa menyesuaikan hak per role (Manager/Supervisor/HR/Finance/Inventory/Direktur) |
| F4 | 12 perbaikan UI/UX terukur (ikon bantuan, keypad PIN 320px, format ribuan Indonesia, pencarian SKU, safe-area iPhone, dll.) + Reset Aplikasi wajib ketik HAPUS + tab internal Kelola Absensi + grup menu Pengaturan | Perilaku lebih aman & konsisten |
| F5 | Watermark foto absensi memakai **logo perusahaan** (Custom Aplikasi), alamat otomatis (Nominatim) + **absen tetap bisa tanpa GPS** (ditandai), QRIS terbaca di **semua browser** (jsQR) + verifikasi CRC + metadata merchant, dokumen/foto besar ke **Firebase Storage** | Opsional: aktifkan Storage (§4) agar hemat kuota Firestore |

---

## 1. AKTIFKAN ANONYMOUS AUTH (WAJIB SEBELUM PUBLISH RULES)

1. Buka **Firebase Console** → project `costlab-f221c` (atau project milikmu).
2. Menu **Authentication → Sign-in method**.
3. Klik **Add new provider → Anonymous → Enable → Save**.

> Tanpa ini, setelah rules v15 di-publish app TIDAK bisa membaca data
> (semua read/write menuntut `request.auth != null`). App tetap aman:
> jika provider belum aktif, jangan publish rules dulu.

## 2. PUBLISH FIRESTORE RULES v15

1. Firebase Console → **Firestore Database → Rules**.
2. Tempel seluruh isi `FIRESTORE-RULES-welp-v15.rules` → **Publish**.
3. Uji cepat: buka app → login owner → semua menu terbaca normal.
   Bila terjadi `permission-denied`, cek ulang langkah 1.

## 3. MIGRASI DATA KOMERSIAL (SEKALI SAJA, PENTING)

Data produk/transaksi lama tersimpan di localStorage perangkat lama.
v15 memindahkannya ke Firestore **otomatis** pada login pertama:

1. Pastikan perangkat yang datanya PALING LENGKAP login lebih dulu
   setelah update ke v15 (owner, perangkat utama).
2. Tunggu ±10 detik (proses import berjalan di latar; lihat console
   `[WELP f1:*]` bila ada galat).
3. Buka app dari perangkat kedua/ketiga → data akan **tertarik dari
   server** (isi server menang; perubahan offline lama yang belum
   tersinkron bisa tertimpa).

## 4. (OPSIONAL TAPI DISARANKAN) FIREBASE STORAGE

Untuk foto absensi & dokumen perusahaan yang besar:

1. Console → **Storage → Get started** (pilih lokasi sama dgn Firestore).
2. Tab **Rules** → tempel `STORAGE-RULES-welp-v15.rules` → **Publish**.
3. Selesai. App otomatis memakai Storage; bila belum aktif, app tetap
   berjalan dengan penyimpanan base64 seperti sebelumnya (fallback).

## 5. SOSIALISASI KE TIM (LOGIN BARU KARYAWAN)

- Alur lama (pilih cabang → PIN cabang → pilih nama) **sudah tidak ada**.
- Karyawan login di `?absen=1`: **ID Toko → Employee ID (mis. PST-001) → PIN pribadi**.
- Owner mengatur/mengganti PIN dari **Manajemen Karyawan** (tombol ganti PIN — PIN baru tampil sekali).
- Karyawan multi-cabang: owner centang **Cabang Tambahan** di akun karyawan; karyawan memilih cabang tiap login.
- Karyawan lupa PIN: atasan (Owner/Admin/Manager/HR/dll.) mereset dari **Aplikasi Karyawan → tab Ajukan → Reset PIN karyawan**.

## 6. CHECKLIST PASCA-DEPLOY

- [ ] Anonymous provider aktif, rules v15 ter-publish, login owner sukses
- [ ] Data lama (produk/transaksi) muncul setelah login pertama perangkat utama
- [ ] Kasir: checkout tunai & QRIS jalan; stok berkurang; Riwayat terisi
- [ ] Device kedua menampilkan data yang sama tanpa import ulang
- [ ] Aplikasi Karyawan: login Employee ID + PIN pribadi; absen selfie masuk ke monitoring
- [ ] Absen tanpa GPS masih bisa dikirim dan muncul tanda TANPA GPS di monitoring
- [ ] Self-order: scan QR meja → pesan → validasi kasir → status di HP pelanggan berubah Divalidasi/Lunas
- [ ] Manajemen Karyawan → Role & Hak Akses tersimpan dan menu menyesuaikan setelah re-login
- [ ] (Opsional) Storage aktif — foto absensi baru tersimpan sebagai URL

## 7. CATATAN KEPERCAYAAN

- Penguncian per-user di level database penuh (custom claims per uid) membutuhkan Cloud Functions — belum termasuk di v15; rules v15 sudah memblokir seluruh akses tanpa sesi, dan permission layer aplikasi (F3) mengatur menu & aksi.
- Reverse geocoding memakai Nominatim/OpenStreetMap (tanpa key, dipanggil hanya saat absen). Bila lambat/gagal, absen tetap tersimpan tanpa alamat.
- Rate-limit PIN disimpan per perangkat; pembatasan server penuh menyusul bersama Cloud Functions.
